set termout off
set feedback off
set echo off
drop table tungsten_load;
exit
