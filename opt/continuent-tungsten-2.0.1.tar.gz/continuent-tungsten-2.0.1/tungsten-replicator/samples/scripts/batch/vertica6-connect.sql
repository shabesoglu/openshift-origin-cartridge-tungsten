# Commands to execute upon connection to Vertica 6. 

# Ensure data load as UTC values. 
SET timezone TO 'UTC'
