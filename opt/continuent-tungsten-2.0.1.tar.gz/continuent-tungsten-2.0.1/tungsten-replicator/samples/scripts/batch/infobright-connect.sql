# InfoBright connection script.  Ensures consistent timezone treatment. 
SET time_zone = '+0:00';
