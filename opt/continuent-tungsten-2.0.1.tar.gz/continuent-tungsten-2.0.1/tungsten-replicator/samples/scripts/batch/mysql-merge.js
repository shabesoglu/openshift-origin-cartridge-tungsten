/**
 * Tungsten Scale-Out Stack
 * Copyright (C) 2013 Continuent Inc.
 * Contact: tungsten@continuent.org
 *
 * Merge script for MySQL.  
 */

/**
 * Called once for each table that must be loaded. 
 * 
 * @see com.continuent.tungsten.replicator.applier.batch.SqlWrapper
 * @see com.continuent.tungsten.replicator.applier.batch.CsvInfo
 * @see com.continuent.tungsten.replicator.applier.batch.JavascriptRuntime
 */
function apply(csvinfo)
{
  // Collect useful data. 
  sqlParams = csvinfo.getSqlParameters();
  csv_file = sqlParams.get("%%CSV_FILE%%");

  // Load CSV to staging table.  This script *must* run on the server.  Tungsten
  // uses drizzle JDBC which does not handle LOAD DATA LOCAL INFILE properly.
  load_data_template = 
    "LOAD DATA INFILE '%%CSV_FILE%%' INTO TABLE %%STAGE_TABLE_FQN%% " 
    + "CHARACTER SET utf8 FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"'"
  load_data = runtime.parameterize(load_data_template, sqlParams);
  logger.info(load_data);
  rows = sql.execute(load_data);

  // Delete rows.  This query applies all deletes that match, need it or not.
  // The inner join syntax used avoids an expensive scan of the base table 
  // by putting it second in the join order. 
  delete_sql_template = "DELETE %%BASE_TABLE%% "
    + " FROM %%STAGE_TABLE_FQN%% s "
    + " INNER JOIN %%BASE_TABLE%% "
    + " ON s.%%PKEY%% = %%BASE_TABLE%%.%%PKEY%% AND s.tungsten_opcode = 'D'"
  delete_sql = runtime.parameterize(delete_sql_template, sqlParams);
  logger.info(delete_sql);
  rows = sql.execute(delete_sql);

  // Insert rows.  This query loads each inserted row provided that the
  // insert is (a) the last insert processed and (b) is not followed by a
  // delete.  The subquery could probably be optimized to a join. 
  replace_template = "REPLACE INTO %%BASE_TABLE%%(%%BASE_COLUMNS%%) "
    + "SELECT %%BASE_COLUMNS%% FROM %%STAGE_TABLE_FQN%% AS stage_a "
    + "WHERE tungsten_opcode='I' AND tungsten_row_id IN "
    + "(SELECT MAX(tungsten_row_id) FROM %%STAGE_TABLE_FQN%% GROUP BY %%PKEY%%)"
  replace = runtime.parameterize(replace_template, sqlParams);
  logger.info(replace);
  rows = sql.execute(replace);
}
